//
//  MyfriendsTableViewCell.swift
//  ClientVK
//
//  Created by Викентий on 22.06.2020.
//  Copyright © 2020 Викентий. All rights reserved.
//

import UIKit

class MyfriendsTableViewCell: UITableViewCell {

    @IBOutlet weak var myfriendsLabel: UILabel!
    
    @IBOutlet weak var myfriendsphoto: UIImageView!
    
}
