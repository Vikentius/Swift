//
//  MygroupsTableViewCell.swift
//  ClientVK
//
//  Created by Викентий on 21.06.2020.
//  Copyright © 2020 Викентий. All rights reserved.
//

import UIKit

class MygroupsTableViewCell: UITableViewCell {

    @IBOutlet weak var mygroupLabel: UILabel!
 
    @IBOutlet weak var photomygroups: UIImageView!
    
}
