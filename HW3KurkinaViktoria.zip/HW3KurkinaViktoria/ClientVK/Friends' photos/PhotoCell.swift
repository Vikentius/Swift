//
//  PhotoCell.swift
//  ClientVK
//
//  Created by Викентий on 22.06.2020.
//  Copyright © 2020 Викентий. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    
@IBOutlet weak var photo: UIImageView!
    
}
